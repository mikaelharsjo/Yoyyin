﻿using System;
using Kiwi.Prevalence;
using Yoyyin.Prevalence.AggregateRoots;
using Yoyyin.Prevalence.Entities;

namespace Yoyyin.Prevalence.Commands.Users
{
    public class AddUserCommand : AbstractCommand<Model, bool>  
    {
        public AddUserCommand()
        {
        }

        public AddUserCommand(User user)
        {
            User = user;
        }

        public User User { get; set; }

        public override Func<bool> Prepare(Model model)
        {
            return () => model.Users.Add(User);
        }
    }
}
