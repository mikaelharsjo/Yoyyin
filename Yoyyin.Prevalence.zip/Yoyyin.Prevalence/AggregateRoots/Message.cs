﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Yoyyin.Prevalence.AggregateRoots
{
    public class Message
    {
    }
}
