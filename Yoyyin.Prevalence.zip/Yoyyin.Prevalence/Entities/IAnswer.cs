namespace Yoyyin.Prevalence.Entities
{
    public interface IAnswer
    {
        int UserID { get; set; }
        string Text { get; set; }
    }
}