namespace Yoyyin.Prevalence.ValueObjects
{
    public class Settings
    {
        bool ShowEmail { get; set; }
        bool ShowAddress { get; set; }
        bool ShowOnMap { get; set; }
    }
}