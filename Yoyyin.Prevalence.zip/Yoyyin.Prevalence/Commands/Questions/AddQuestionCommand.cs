﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Kiwi.Prevalence;
using Yoyyin.Prevalence.AggregateRoots;
using Yoyyin.Prevalence.Entities;

namespace Yoyyin.Prevalence.Commands.Questions
{
    public class AddQuestionCommand : AbstractCommand<Model, bool>
    {
        public AddQuestionCommand() { }

        public AddQuestionCommand(Question question)
        {
            Question = question;
        }

        public Question Question { get; set; }

        public override Func<bool> Prepare(Model model)
        {
            return () => model.BaseData.Questions.Add(Question);
        }
    }
}
