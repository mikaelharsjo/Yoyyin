﻿using System.Collections.Generic;
using Yoyyin.Prevalence.Entities;
using Yoyyin.Prevalence.ValueObjects;

namespace Yoyyin.Prevalence.AggregateRoots
{
    public class User //: IUser
    {
        public User()
        {
            Visits = new List<Visit>();
        }

        public int UserId { get; set; }
        public string Name { get; set; }
        //byte[] Image { get; set; }
        public string CVFileName { get; set; }
        //string FacebookID { get; set; }
        public bool Active { get; set; }
        //public int UserType { get; set; }
        public string UserTypeDescription { get; set; }
        public string Alias { get; set; }

        public Address Adress { get; set; }
        public Settings Settings { get; set; }
        public SniCategory Category { get; set; }
        public UserType UserType { get; set; }
        public SearchProfile SearchProfile { get; set; }


        public IEnumerable<string> Urls { get; set; }
        public IEnumerable<int> QuestionIds { get; set; }
        public IEnumerable<int> IncomingMessageIds { get; set; }
        public IEnumerable<int> SentMessageIds { get; set; }

        public IEnumerable<Idea> Ideas { get; set; }
        //public IEnumerable<Answer> Answers { get; set; }
        public IEnumerable<Bookmark> Bookmarks { get; set; }
        public IEnumerable<Comment> Comments { get; set; }
        public IEnumerable<Visit> Visits { get; set; }
    }
}
