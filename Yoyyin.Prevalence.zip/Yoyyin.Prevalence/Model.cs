﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Yoyyin.Prevalence.AggregateRoots;
using Yoyyin.Prevalence.Entities;

namespace Yoyyin.Prevalence
{
    public class BaseData
    {
        public BaseData()
        {
            Users = new HashSet<User>();
            Questions = new HashSet<Question>();
        }

        public HashSet<User> Users { get; set; }
        public HashSet<Question> Questions { get; set; }
    }

    public class Model
    {
        // Basedata should be the only serialized datamember since the rest are calculated or application state dependent
        //[DataMember]
        public BaseData BaseData { get; set; }

        public Model()
        {
            BaseData = new BaseData();
            //Invalidate();
        }
        
        public HashSet<User> Questions
        {
            get { return BaseData.Users; }
            set { BaseData.Users = value; }
        }

        public HashSet<User> Users
        {
            get { return BaseData.Users; }
            set { BaseData.Users = value; }
        }


        private void Invalidate()
        {
            // set indexes?
        }
    }

}
