namespace Yoyyin.Prevalence.Entities
{
    public class Idea
    {
        string CompanyName { get; set; }
        string BusinessTitle { get; set; }
        string BusinessDescription { get; set; }        
        string SniHeadID { get; set; }
        string SniNo { get; set; }
    }
}