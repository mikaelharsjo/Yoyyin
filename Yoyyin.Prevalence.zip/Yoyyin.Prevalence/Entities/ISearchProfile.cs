using System.Collections.Generic;
using Yoyyin.Prevalence.ValueObjects;

namespace Yoyyin.Prevalence.Entities
{
    public interface ISearchProfile
    {
        string SearchWords { get; set; }
        string SearchWordsCompetence { get; set; }
        string SearchWordsCompetenceNeeded { get; set; }
        IEnumerable<IUserType> UserTypesNeeded { get; set; }
        Dictionary<IUserType, string> UserTypesNeededDescriptions { get; set; }
    }
}