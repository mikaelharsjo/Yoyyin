namespace Yoyyin.Prevalence.ValueObjects
{
    public interface IUserType
    {
        string Title { get; set; }
        string Description { get; set; }
        int UserTypeId { get; set; }
    }

    public class UserType : IUserType
    {
        public string Title { get; set; }

        public string Description { get; set; }

        public int UserTypeId { get; set; }
    }
}