﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Yoyyin.Prevalence.Entities
{
    public class Bookmark
    {
        public int UserId { get; set; }
        
        public DateTime Created { get; set; }
    }
}
