﻿namespace Yoyyin.Prevalence.Entities
{
    public class Answer : IAnswer
    {
        //public virtual int AnswerID { get; set; }
        public int UserID { get; set; }
        public string Text { get; set; }
    }
}
