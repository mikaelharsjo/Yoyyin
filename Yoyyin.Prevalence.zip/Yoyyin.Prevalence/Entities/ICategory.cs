namespace Yoyyin.Prevalence.Entities
{
    public interface ICategory
    {
        string CategoryId { get; set; }
        string Title { get; set; }
    }
}