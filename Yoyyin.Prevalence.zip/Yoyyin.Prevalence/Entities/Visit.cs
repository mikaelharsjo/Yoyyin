using System;

namespace Yoyyin.Prevalence.Entities
{
    public class Visit
    {
        public int UserId { get; set; }
        public DateTime Created { get; set; }
    }
}