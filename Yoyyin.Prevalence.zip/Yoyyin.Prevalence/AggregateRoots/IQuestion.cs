using System;
using System.Collections.Generic;
using Yoyyin.Prevalence.Entities;

namespace Yoyyin.Prevalence.AggregateRoots
{
    public interface IQuestion
    {
        int QuestionId { get; set; }
        int UserId { get; set; }
        int Category { get; set; }
        DateTime Created { get; set; }
        string Text { get; set; }
        string Title { get; set; }
        IEnumerable<Answer> Answers { get; set; }
    }
}