﻿using System;
using System.Linq;
using FizzWare.NBuilder;
using Kiwi.Prevalence;
using NUnit.Framework;
using Yoyyin.Prevalence.AggregateRoots;
using Yoyyin.Prevalence.Commands.Questions;
using Yoyyin.Prevalence.Commands.Users;
using Yoyyin.Prevalence.Entities;

namespace Yoyyin.Prevalence.Tests
{
    [TestFixture]
    public class YoyyinScrathPad
    {
        private Repository<Model> _repo;
        private User _firstUser;

        [SetUp]
        public void Setup()
        {
            var modelFactory = new ModelFactory<Model>(() => new Model());
            _repo = new Repository<Model>(new RepositoryConfiguration(), modelFactory);
            
            //_repo.Purge();
            
            var users = Builder<User>
                        .CreateListOfSize(1)
                        .TheFirst(1)
                            .With(u => u.Name = "Kalle Anka")
                        .Build();

            foreach(var user in users)
            {
                _repo.Execute(new AddUserCommand(user));
            }

            var questions = Builder<Question>
                .CreateListOfSize(10)
                .All().With(q => q.UserId = users.First().UserId)
                .Build();

            foreach(var question in questions)
            {
                question.Answers = Builder<Answer>
                                .CreateListOfSize(5)
                                .Random(5)
                                .Build();

                _repo.Execute(new AddQuestionCommand(question));
            }

            Console.Out.WriteLine("Revision is now {0}", _repo.Revision);
            //Console.Out.WriteLine("Model size is {0}", _repo.Query(m => m.Users.Count));
        }

        [Test]
        public void TestQuery()
        {
            _firstUser = _repo.Query(u => u.Users.First());
            Console.Out.WriteLine("Revision is now {0}", _repo.Revision);
            Assert.That(_firstUser.Name, Is.EqualTo("Kalle Anka"));
        }

        //[Test]
        //public void FirstUserHaveAsked10Questions()
        //{
        //    _firstUser = _repo.Query(u => u.Users.First());
        //    var questionCount = _repo.Query(q => q.Questions.Where(question => question.UserId == _firstUser.UserId)).Count();

        //    Assert.That(questionCount, Is.EqualTo(10));
        //}

        //[Test]
        //public void FirstQuestionIsAnswered5Times()
        //{
        //    Assert.That(_repo.Query(q => q.Questions.First().Answers.Count()), Is.EqualTo(5));
        //}

        [TearDown]
        public void TearDown()
        {
            foreach (User user in _repo.Model.Users)
            {
                Console.Out.WriteLine("UserName: {0}", user.Name);
                Console.Out.WriteLine("IdeaCount: {0}", user.Ideas != null ? user.Ideas.Count() : 0);
                Console.Out.WriteLine("BookmarkCount: {0}", user.Bookmarks != null ? user.Bookmarks.Count() : 0);
                Console.Out.WriteLine("BookmarkCount: {0}", user.Comments != null ? user.Comments.Count() : 0);
                Console.Out.WriteLine("VisitCount: {0}", user.Visits.Count());
            }

           // _repo.Dispose();
        }
    }
}
