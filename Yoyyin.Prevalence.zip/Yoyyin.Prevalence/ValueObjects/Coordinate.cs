namespace Yoyyin.Prevalence.ValueObjects
{
    public class Coordinate
    {        
        double Latitude { get; set; }
        double Longitude { get; set; } 
    }
}