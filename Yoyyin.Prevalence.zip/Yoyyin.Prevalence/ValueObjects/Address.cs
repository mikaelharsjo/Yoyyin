namespace Yoyyin.Prevalence.ValueObjects
{
    public class Address
    {
        string Street { get; set; }
        string ZipCode { get; set; }
        string City { get; set; }
        string Phone { get; set; }

        private Coordinate Coordinate { get; set; }
 
    }
}