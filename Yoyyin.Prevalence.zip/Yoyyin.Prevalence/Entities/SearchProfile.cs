using System.Collections.Generic;
using Yoyyin.Prevalence.ValueObjects;

namespace Yoyyin.Prevalence.Entities
{
    public class SearchProfile : ISearchProfile
    {
        public string SearchWords { get; set; }
        public string SearchWordsCompetence { get; set; }
        public string SearchWordsCompetenceNeeded { get; set; }
        public IEnumerable<IUserType> UserTypesNeeded { get; set; }
        public Dictionary<IUserType, string> UserTypesNeededDescriptions { get; set; }
    }
}